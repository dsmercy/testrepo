import logo from './logo.svg';
import './assets/scss/main.scss'
import header from './assets/img/logo.png'
import { useEffect, useState } from 'react';


function App() {
  const month_names = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

  const isLeapYear = (year) => {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  };

  const getFebDays = (year) => {
    return isLeapYear(year) ? 29 : 28;
  };

  const [selectedDay, setSelectedDay] = useState(null);
  const [currMonth, setCurrMonth] = useState(new Date().getMonth());
  const [currYear, setCurrYear] = useState(new Date().getFullYear());

  useEffect(() => {
    generateCalendar(currMonth, currYear);
  }, [currMonth, currYear]);

  const generateCalendar = (month, year) => {
    const calendarDays = document.querySelector('.calendar-days');
    const calendarHeaderYear = document.querySelector('#year');
    const month_picker = document.querySelector('#month-picker');

    const daysOfMonth = [31, getFebDays(year), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    calendarDays.innerHTML = '';

    const currDate = new Date();
    if (month === undefined) month = currDate.getMonth();
    if (year === undefined) year = currDate.getFullYear();

    const currMonthName = month_names[month];
    month_picker.innerHTML = currMonthName;
    calendarHeaderYear.innerHTML = year;

    const firstDay = new Date(year, month, 1);
    const prevMonth = month === 0 ? 11 : month - 1;
    const prevYear = month === 0 ? year - 1 : year;
    const nextMonth = month === 11 ? 0 : month + 1;
    const nextYear = month === 11 ? year + 1 : year;

    for (let i = 0; i <= daysOfMonth[month] + firstDay.getDay() - 1; i++) {
      const day = document.createElement('div');
      if (i >= firstDay.getDay()) {
        day.classList.add('calendar-day-hover');
        day.innerHTML = i - firstDay.getDay() + 1;
        day.innerHTML += `<span class="d-none"></span>
                          <span></span>
                          <span></span>
                          <span></span>`;
        if (
          i - firstDay.getDay() + 1 === currDate.getDate() &&
          year === currDate.getFullYear() &&
          month === currDate.getMonth()
        ) {
          day.classList.add('curr-date');
        }

        day.addEventListener('click', () => {
          if (selectedDay) {
            selectedDay.style.backgroundColor = '';
            selectedDay.style.color = '';
          }
          day.style.backgroundColor = '#0db955';
          day.style.color = '#fff';
          setSelectedDay(day);
        });
      } else {
        day.classList.add('disabled');
      }
      calendarDays.appendChild(day);
    }

    document.querySelector('#prev-year').onclick = () => {
      generateCalendar(prevMonth, year);
    };

    document.querySelector('#next-year').onclick = () => {
      generateCalendar(nextMonth, year);
    };
  };

  const handleMonthClick = (index) => {
    const monthList = document.querySelector('.month-list');
    monthList.classList.remove('show');
    setCurrMonth(index);
    generateCalendar(index, currYear);
  };

  const handleMonthPickerClick = () => {
    const monthList = document.querySelector('.month-list');
    monthList.classList.add('show');
  };

  const handleDarkModeToggle = () => {
    document.querySelector('body').classList.toggle('light');
    document.querySelector('body').classList.toggle('dark');
  };
  return (
    <>
  <header id="page-top" className="bg-white p-4">
    <div className="container">
      <div className="col-xl-12 col-lg-12 col-md-12 col-12 text-center">
        <img src={header} alt="" className="logo" />
      </div>
    </div>
  </header>
  <section className="main-section">
      <div className="content-center d-flex justify-content-center extra-padding">
        <div className="calendar container-div">
          <div className="ryt-sec cl-width">
            <div className="content-inside-ryt calendly">
              <h5 className="fw-bold select-head-text">Select a Date & Time</h5>
              <div className="calendly-date-time div-date">
                <div className="width-shrink">
                  <div className="calendly-inside-div">
                    <div className="calendar-header">
                      <div className="year-picker">
                        <span className="year-change" id="prev-year">
                          <pre>{'<'}</pre>
                        </span>
                        <div className="month-year-note">
                          <span className="month-picker" id="month-picker" onClick={handleMonthPickerClick}>
                            {month_names[currMonth]}
                          </span>
                          <span id="year" className="select-year"></span>
                          <div className="year-list"></div>
                        </div>
                        <span className="year-change" id="next-year">
                          <pre>{'>'}</pre>
                        </span>
                      </div>
                    </div>
                    <div className="calendar-body">
                      <div className="calendar-week-day">
                        <div>Sun</div>
                        <div>Mon</div>
                        <div>Tue</div>
                        <div>Wed</div>
                        <div>Thu</div>
                        <div>Fri</div>
                        <div>Sat</div>
                      </div>
                      <div className="calendar-days"></div>
                    </div>
                    <div className="calendar-footer">
                      <div className="toggle">
                        <div className="dark-mode-switch" onClick={handleDarkModeToggle}>
                          <div className="dark-mode-switch-ident"></div>
                        </div>
                      </div>
                    </div>
                    <div className="month-list">
                      {month_names.map((month, index) => (
                        <div key={index} data-month={index} onClick={() => handleMonthClick(index)}>
                          {month}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  <footer className="text-center bg-white py-3">
    <div className="container">
      <div className="col-lg-12">
        <div className="spine">
          <p className="mb-2">
            We do not charge a fee for this service, but we do receive a
            commission directly from our partners following successful
            introductions from this website. Any information we provide is for
            the purpose of illustrating the products promoted on this site only
            and should not be read as financial advice.
          </p>
          <p className="mb-0">
            Copyright © YourLife Insured. 2022 | All Rights Reserved
          </p>
          <p className="mb-3">yourlife-insured.co.uk</p>
        </div>
        <ul className="p-0">
          <li className="d-inline border-end border-secondary">
            <a
              className="rp_clk"
              data-bs-toggle="modal"
              data-bs-target="#terms"
            >
              Terms and Conditions
            </a>
          </li>
          <li className="d-inline">
            <a
              className="rp_clk"
              data-bs-toggle="modal"
              data-bs-target="#privacy"
            >
              Privacy Policy
            </a>
          </li>
        </ul>
      </div>
    </div>
  </footer>
</>

  );
}

export default App;
