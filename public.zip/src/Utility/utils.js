
// import {  toast } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';

// export const toastifyFunction = (status, message) => {
//     if (status !== 200) {
//       toast.error(message);
//     } else {
//       toast.success(message);
//     }
//   };