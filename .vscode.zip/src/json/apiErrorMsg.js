export default {
  msg: {
    INTERNAL_ERROR_MSG: "Something went wrong!!!",
    NETWORK_MSG: "Network Error!, Please check your connection.",
  },
  code: {
    ERR_NETWORK: "ERR_NETWORK",
    ERR_BAD_REQUEST: "ERR_BAD_REQUEST",
  },
};
