﻿using Dapper;
using DapperRepo.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DapperRepo.DAL
{
    public class EmployeeDAL
    {
        DALConnection con = new DALConnection();
        SqlConnection connection;

        public IEnumerable<Employee> GetEmployees(int Mode)
        {
            connection = new SqlConnection(con.GetConnection());
            var param = new DynamicParameters();
            param.Add("@Mode", Mode);            
            param.Add("@Inserted", Mode);            
            var data = connection.Query<Employee>("ManageEmployee", param, null, true, 0, commandType: System.Data.CommandType.StoredProcedure);
            int outParam = param.Get<int>("@Inserted");
            return data;
        }

        public Employee GetEmployeeById(int Mode, int Id)
        {
            connection = new SqlConnection(con.GetConnection());
            var param = new DynamicParameters();
            param.Add("@Mode", Mode);
            param.Add("@Id", Id);
            param.Add("@Inserted", Mode);
            return connection.Query<Employee>("ManageEmployee", param, null, true, 0, commandType: System.Data.CommandType.StoredProcedure).SingleOrDefault();
        }

        public int AddEmployee(int Mode, Employee emp)
        {
            connection = new SqlConnection(con.GetConnection());
            var param = new DynamicParameters();
            param.Add("@Mode", Mode);
            param.Add("@Id", emp.Id);
            param.Add("@Username", emp.Username);
            param.Add("@Password", emp.Password);
            param.Add("@Salary", emp.Salary);
            param.Add("@Email", emp.Email);
            param.Add("@Inserted", Mode);
            connection.Execute("ManageEmployee", param, null, 0, commandType: System.Data.CommandType.StoredProcedure);
            return param.Get<int>("@Inserted");
        }

    }
}
