﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DapperRepo.DAL
{
    public class DALConnection
    {
        public string Connection { get; set; }

        public string GetConnection() {
            return ConfigurationManager.ConnectionStrings["DefaultConnection"].ToString();
        }
    }
}
