﻿using DapperRepo.DAL;
using DapperRepo.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DapperRepo.BAL
{
    public class EmployeeBAL
    {
        EmployeeDAL employeeDAL = new EmployeeDAL();

        public IEnumerable<Employee> GetEmployees(int Mode)
        {
            return employeeDAL.GetEmployees(Mode);  
        }

        public Employee GetEmployeeById(int Mode, int Id)
        {
            return employeeDAL.GetEmployeeById(Mode, Id);
        }

        public int AddEmployee(int Mode, Employee emp)
        {
            return employeeDAL.AddEmployee(Mode, emp);  
        }
    }
}
