import {Formik } from 'formik';
import MyTextInput from '../common/MyTextInput';
import * as Yup from 'yup'
import { LoginFormValues } from '../../models/userModels';
import { actionCreators } from "../../store/slices/userSlice";
import { store } from "../../store/store";
import { Link } from 'react-router-dom';
import { useHistory } from 'react-router-dom';

export default function Login() {
    const history = useHistory();

const LoginHandler = async (values:LoginFormValues)=>{
  const userData =  store.dispatch(await actionCreators.login(values));
}

    return (
        <div className="container container-fluid">
            <div className="row wrapper">
                <div className="col-10 col-lg-5">
                    <Formik
                        initialValues={{
                            username: '',
                            password: ''
                        }}
                        onSubmit={LoginHandler}
                        validationSchema={Yup.object().shape({
                            username: Yup.string()
                                .required('Username is required'),
                            password: Yup.string()
                                .required(
                                    'Password is required'
                                ),
                        })}
                    >
                        {({ handleSubmit, isSubmitting, errors }) => (
                            <form className="shadow-lg" onSubmit={handleSubmit} autoComplete="off">
                                <h1 className="mb-3">Login</h1>
                                <div className="form-group">
                                    <MyTextInput name="username" placeholder="Username"/>
                                    <MyTextInput name="password" type="password" placeholder="password"/>
                                </div>

                                <Link to="" className="float-right mb-4">Forgot Password?</Link>

                                <button
                                    id="login_button"
                                    type="submit"
                                    className="btn btn-block py-3"
                                >
                                    LOGIN
                                </button>

                                <Link to="/register" className="float-right mt-3">New User?</Link>
                            </form>
                        )}
                    </Formik>
                </div>
            </div>
        </div>
    )
}
