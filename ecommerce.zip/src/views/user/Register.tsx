import React from 'react'
import { Formik } from 'formik';
import MyTextInput from '../common/MyTextInput';
import * as Yup from 'yup'
import { RegisterFormValues } from '../../models/userModels';
import { actionCreators } from "../../store/slices/userSlice";
import { store } from "../../store/store";

export default function Register() {
  return (
    <div className="container container-fluid">
      <div className="row wrapper">
        <div className="col-10 col-lg-5">
          <Formik
            initialValues={{
              username: '',
              email:'',
              password: ''
            }}
            onSubmit={async (values: RegisterFormValues) => { store.dispatch(await actionCreators.register(values)) }}
            validationSchema={Yup.object().shape({
              username: Yup.string()
                .required('Username is required'),
                email: Yup.string()
                .email()
                .required('Email is required'),
              password: Yup.string()
                .required(
                  'Password is required'
                ),
            })}
          >
            {({ handleSubmit, isSubmitting, errors }) => (
              <form className="shadow-lg" onSubmit={handleSubmit} autoComplete="off">
                <h1 className="mb-3">Register</h1>
                <div className="form-group">
                  <MyTextInput name="username" placeholder="Username" />
                  <MyTextInput name="email" placeholder="Email" />
                  <MyTextInput name="password" type="password" placeholder="password" />
                </div>
                <button
                  id="register_button"
                  type="submit"
                  className="btn btn-block py-3"
                >
                  Register
                </button>
              </form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  )
}
