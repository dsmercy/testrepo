import * as React from 'react';
import { BrowserRouter } from 'react-router-dom';
import { Container } from 'reactstrap';
import NavMenu from './Header';

const Layout = (props: { children?: React.ReactNode }) => (
    <BrowserRouter>
        <React.Fragment>
            <NavMenu />
            <Container>
                <div className="container">
                    {props.children}
                </div>
            </Container>
        </React.Fragment>
    </BrowserRouter>
);

export default Layout;