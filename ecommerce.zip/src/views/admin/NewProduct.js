import React, { Fragment, useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useAppSelector, useAppDispatch } from '../../store/hooks';
import { categoriesSelector, actionCreators } from '../../store/slices/productStore';
import { store } from "../../store/store";
import agent from "../../api/agent";
import MyTextArea from '../common/MyTextArea';
import MySelectInput from '../common/MySelectInput';
import MyTextInput from '../common/MyTextInput';
import { Formik } from 'formik';
import * as Yup from 'yup'

const NewProduct = () => {

    const [images, setImages] = useState([]);
    const [imagesPreview, setImagesPreview] = useState([])
    const [categories, setcategories] = useState([]);
    const [category, setCategory] = useState('');
    const dispatch = useDispatch();

    useEffect(() => {
        // agent.Categories.getAllCategory().then(response => setcategories((id,name)=>{text:name}));
        agent.Categories.getAllCategory().then(response => setcategories(response.map(({ name, id }) => ({ text: name, value: id }))));
    }, []);

    const submiHandler = (values) => {
        const userData =  store.dispatch(actionCreators.CreateProducts(values));
        
    }

    const onChange = e => {

        const files = Array.from(e.target.files)

        setImagesPreview([]);
        setImages([])

        files.forEach(file => {
            const reader = new FileReader();

            reader.onload = () => {
                if (reader.readyState === 2) {
                    setImagesPreview(oldArray => [...oldArray, reader.result])
                    setImages(oldArray => [...oldArray, reader.result])
                }
            }
            reader.readAsDataURL(file)
        })
    }

    var CategoryOptions = categories.map((item) => {
        return (
            <option key={item.value} value={item.value} >{item.text}</option>
        )
    });

    return (
        <Fragment>
            <div className="container container-fluid">
                <div className="row wrapper">
                    <div className="col-10 col-lg-5">
                        <Formik
                            initialValues={{
                                name: '',
                                description: '',
                                image: '',
                                sellingprice: 0,
                                unitsinstock: 0,
                                productcategoryid: category
                            }}
                            onSubmit={submiHandler}
                            validationSchema={Yup.object().shape({
                                name: Yup.string()
                                    .required('name is required'),
                                description: Yup.string()
                                    .required(
                                        'description is required'
                                    ),
                                // image: Yup.mixed().required(
                                //         'image is required'
                                //     ),
                                sellingprice: Yup.string()
                                    .required(
                                        'sellingprice is required'
                                    ),
                                unitsinstock: Yup.string()
                                    .required(
                                        'stock is required'
                                    ),
                                productcategoryid: Yup.string()
                                    .required(
                                        'category is required'
                                    ),
                            })}
                        >
                            {({ handleSubmit, isSubmitting, errors, handleChange, touched, setFieldValue }) => (
                                <form className="shadow-lg" onSubmit={handleSubmit} autoComplete="on">
                                    <h1 className="mb-3">Product</h1>
                                    <div className="form-group">
                                        <MyTextInput name="name" placeholder="Name" />
                                        <MyTextArea name="description" rows="3" placeholder="description" />
                                        <MyTextInput name="sellingprice" placeholder="selling price" />
                                        <MyTextInput name="unitsinstock" placeholder="stock" />
                                        <label></label>
                                        <div className='custom-file mt-3'>
                                            <input name="image" type="file" onChange={(event) => {
                                                setFieldValue("image", event.currentTarget.files[0]);
                                            }} className="form-control" />
                                        </div>
                                        {/* {imagesPreview.map(img => (
                                            <img src={img} key={img} alt="Images Preview" className="mt-3 mr-2" width="55" height="52" />
                                        ))} */}
                                        <label></label>
                                        <select className="form-control mt-3" placeholder="select category" name="productcategoryid" onChange={handleChange}>
                                            <option>-select category-</option>
                                            {CategoryOptions}
                                        </select>
                                        {errors.productcategoryid &&
                                            touched.productcategoryid &&
                                            <div className="input-feedback">
                                                {errors.productcategoryid}
                                            </div>}
                                    </div>
                                    <button
                                        id="product_button"
                                        type="submit"
                                        className="btn btn-block py-3"
                                    >
                                        Create
                                    </button>
                                </form>
                            )}
                        </Formik>
                    </div>
                </div>
            </div>
        </Fragment>
    )
}

export default NewProduct
