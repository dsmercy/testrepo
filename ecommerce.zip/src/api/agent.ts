import axios, { AxiosError, AxiosResponse } from "axios";
import { User, LoginFormValues, RegisterFormValues } from "../models/userModels";
import { toast } from 'react-toastify';
import { RegisterResponse } from "../models/ResponseModels";
import { history } from "..";
import { PaginatedResult } from "../models/pagination";
import { Category } from "../models/categoryModels";
import { Product } from "../models/productModels";


const sleep = (delay: number) => {
  return new Promise((resolve) => {
    setTimeout(resolve, delay);
  });
};

axios.interceptors.request.use((config) => {
  const token = ''; //from local storage
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// const token = useSelector((state: RootState) => state.entities.user.token)

axios.defaults.baseURL = 'https://localhost:44378/api';
 
// Add a response interceptor
axios.interceptors.response.use(function (response) {
  // Do something with response data
  return response;
}, function (error) {
  // Do something with response error
  toast(error.response.data.message, {
        position: "bottom-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
        });
  return Promise.reject(error);
});



// axios.interceptors.response.use(async (response) => {
//   if (process.env.NODE_ENV === "development") await sleep(1000);
//     const pagination = response.headers["pagination"];
//     if (pagination) {
//       response.data = new PaginatedResult(response.data, JSON.parse(pagination));
//       return response as AxiosResponse<PaginatedResult<any>>;
//     }
//     console.log('axios.interceptors.response.use');
//     return response;
// },error => {
//   if (error.response.status === 401) {
//    console.log(error,'Invalid access');
//   }
//   return error;
// });
// (error: AxiosError) => {
//   const { data, status, config, headers } = error.response!;
//   switch (status) {
//     case 400:
//       if (config.method === "get" && data.errors.hasOwnProperty("id")) {
//         history.push("/not-found");
//       }
//       if (data.errors) {
//         const modalStateErrors = [];
//         for (const key in data.errors) {
//           if (data.errors[key]) {
//             modalStateErrors.push(data.errors[key]);
//           }
//         }
//         throw modalStateErrors.flat();
//       } else {
//         toast.error(data);
//       }
//       break;
//     case 401:
//       if (status === 401 && headers["www-authenticate"]?.startsWith('Bearer error="invalid_token"')) {
//         // store.userStore.logout();
//         toast.error("Session expired - please login again");
//       }
//       break;
//     case 404:
//       // history.push("/not-found");
//       break;
//     case 500:
//       history.push("/server-error");
//       break;
//   }
//   return Promise.reject(error);
// }
// );

const config = {     
  headers: { 'content-type': 'multipart/form-data' }
}

const responseBody = <T>(response: AxiosResponse<T>) => response.data;

const requests = {
  get: <T>(url: string) => axios.get<T>(url).then(responseBody),
  post: <T>(url: string, body: {}) => axios.post<T>(url, body).then(responseBody),
  put: <T>(url: string, body: {}) => axios.put<T>(url, body).then(responseBody),
  del: <T>(url: string) => axios.delete<T>(url).then(responseBody),
};


const Account = {
  values: () => requests.get("/Values"),
  login: (user: LoginFormValues) => requests.post<User>("/Authenticate/login", user),
  register: (user: RegisterFormValues) => requests.post<RegisterResponse>("/Authenticate/register", user),
  fbLogin: (accessToken: string) => requests.post<User>(`/account/fbLogin?accessToken=${accessToken}`, {}),
  refreshToken: () => requests.post<User>("/account/refreshToken", {}),
  verifyEmail: (token: string, email: string) =>
    requests.post<void>(`/account/verifyEmail?token=${token}&email=${email}`, {}),
  resendEmailConfirm: (email: string) => requests.get(`/account/resendEmailConfirmationLink?email=${email}`),
};

const Categories = {
  getAllCategory: () => requests.get<Category[]>(`/category`),
  CreateCategory: (category: Category) => requests.post<RegisterResponse>("/category", category),
};

const Products = {
  getAllProducts: () => requests.get<Product[]>(`/Products`),
  CreateProduct: (product: Product) => requests.post<RegisterResponse>("/Products", product),
};


const agent = {
  Account,
  Categories,
  Products
};

export default agent;
