import { Category } from '../../models/categoryModels';
import { createSlice, PayloadAction, Dispatch } from '@reduxjs/toolkit';
import { RootState } from '../store';
import agent from "../../api/agent";
import { toast } from 'react-toastify';
import { history } from '../..';

// Declare an interface of the store's state.
export interface CategoryStoreState {
  collection: Category[];
}

// Create the slice.
export const categorySlice = createSlice({
  name: "category",
  initialState: {
    collection: []
  } as CategoryStoreState,
  reducers: {
    setFetching: (state, action: PayloadAction<boolean>) => {
      // state.isAuthenticated = action.payload;
    },
    setData: (state, action: PayloadAction<Category[]>) => {
      state.collection = action.payload;
    },
    addData: (state, action: PayloadAction<Category>) => {
      state.collection = [...state.collection, action.payload];
    },
    updateData: (state, action: PayloadAction<Category>) => {
      // We need to clone collection (Redux-way).
      // var collection = [...state.collection];
      // var entry = collection.find(x => x.id === action.payload.id);
      // entry.username = action.payload.username;
      // entry.displayName = action.payload.displayName;
      // entry.token = action.payload.token;
      state.collection = [...state.collection];
    },
    deleteData: (state, action: PayloadAction<{ id: number }>) => {
      state.collection = state.collection.filter(x => x.id !== action.payload.id);
    }
  }
});

// Export reducer from the slice.
export const { setFetching, setData, addData, updateData } = categorySlice.actions;

// The function below is called a selector and allows us to select a value from
// the state. Selectors can also be defined inline where they're used instead of
// in the slice file. For example: `useSelector((state: RootState) => state.counter.value)`
export const categoriesSelector = (state: RootState) => state.entities.category;

export default categorySlice.reducer;


// Define actions creators.
export const actionCreators = {

  getAllCategories: (model: Category) => async (dispatch: Dispatch) => {
    try {
      const result = await agent.Categories.getAllCategory();
      if (result.length > 0) {
        dispatch(categorySlice.actions.setData(result));
      } else {
        toast('No data found', {
          position: "bottom-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
        });
      }
    } catch (error) {
      toast(String(error), {
        position: "bottom-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
      });
    }
  },
};