import { Product } from './../../models/productModels';
import { createSlice, PayloadAction, Dispatch } from '@reduxjs/toolkit';
import { RootState } from '../store';
import agent from "../../api/agent";
import { toast } from 'react-toastify';
import { history } from '../..';

// Declare an interface of the store's state.
export interface ProductStoreState {
  collection: Product[];
}

// Create the slice.
export const ProductSlice = createSlice({
  name: "product",
  initialState: {
    collection: []
  } as ProductStoreState,
  reducers: {
    setFetching: (state, action: PayloadAction<boolean>) => {
      // state.isAuthenticated = action.payload;
    },
    setData: (state, action: PayloadAction<Product[]>) => {
      state.collection = action.payload;
    },
    addData: (state, action: PayloadAction<Product>) => {
      state.collection = [...state.collection, action.payload];
    },
    updateData: (state, action: PayloadAction<Product>) => {
      // We need to clone collection (Redux-way).
      // var collection = [...state.collection];
      // var entry = collection.find(x => x.id === action.payload.id);
      // entry.username = action.payload.username;
      // entry.displayName = action.payload.displayName;
      // entry.token = action.payload.token;
      state.collection = [...state.collection];
    },
    deleteData: (state, action: PayloadAction<{ id: number }>) => {
      state.collection = state.collection.filter(x => x.id !== action.payload.id);
    }
  }
});

// Export reducer from the slice.
export const { setFetching, setData, addData, updateData } = ProductSlice.actions;

// The function below is called a selector and allows us to select a value from
// the state. Selectors can also be defined inline where they're used instead of
// in the slice file. For example: `useSelector((state: RootState) => state.counter.value)`
export const ProductsSelector = (state: RootState) => state.entities.product;

export default ProductSlice.reducer;


// Define actions creators.
export const actionCreators = {

  getAllProducts: () => async (dispatch: Dispatch) => {
    try {
      const result = await agent.Products.getAllProducts();
      if (result.length > 0) {
        dispatch(ProductSlice.actions.setData(result));
      } else {
        toast('No data found', {
          position: "bottom-right",
          autoClose: 3000,
          hideProgressBar: false,
          closeOnClick: true,
        });
      }
    } catch (error) {
      toast(String(error), {
        position: "bottom-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
      });
    }
  },

  CreateProducts: (model: Product) => async (dispatch: Dispatch) => {
    try {
      console.log(model,'CreateProducts Slice');
      const result = await agent.Products.CreateProduct(model);
      if (result) {
        // dispatch(ProductSlice.actions.setData(result));
      }
    } catch (error) {
      toast(String(error), {
        position: "bottom-right",
        autoClose: 3000,
        hideProgressBar: false,
        closeOnClick: true,
      });
    }
  },
  
};