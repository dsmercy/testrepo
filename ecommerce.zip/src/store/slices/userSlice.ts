import { User, LoginFormValues, RegisterFormValues } from '../../models/userModels';
import { createSlice, PayloadAction, Dispatch } from '@reduxjs/toolkit';
import { RootState} from '../store';
import agent from "../../api/agent";
import { toast } from 'react-toastify';
import { history } from '../..';

// Declare an interface of the store's state.
export interface UserStoreState {
  token:string;
  username:string;
  isAuthenticated: boolean;
  collection: User[];
}

// Create the slice.
export const userSlice = createSlice({
  name: "user",
  initialState: {
    token:'',
    username:'',
    isAuthenticated: false,
    collection: []
  } as UserStoreState,
  reducers: {
    login: (state, action: PayloadAction<User>) => {
      state.token = action.payload.token;
      state.username = action.payload.username;
    },
    logout: (state) => {
      state.token = '';
      state.username = '';
    },
    setFetching: (state, action: PayloadAction<boolean>) => {
      state.isAuthenticated = action.payload;
    },
    setData: (state, action: PayloadAction<User[]>) => {
      state.collection = action.payload;
    },
    addData: (state, action: PayloadAction<User>) => {
      state.collection = [...state.collection, action.payload];
    },
    updateData: (state, action: PayloadAction<User>) => {
      // We need to clone collection (Redux-way).
      // var collection = [...state.collection];
      // var entry = collection.find(x => x.id === action.payload.id);
      // entry.username = action.payload.username;
      // entry.displayName = action.payload.displayName;
      // entry.token = action.payload.token;
      state.collection = [...state.collection];
    },
    deleteData: (state, action: PayloadAction<{ id: number }>) => {
      state.collection = state.collection.filter(x => x.id !== action.payload.id);
    }
  }
});

// Export reducer from the slice.
export const { setFetching, setData, addData, updateData } = userSlice.actions;

// The function below is called a selector and allows us to select a value from
// the state. Selectors can also be defined inline where they're used instead of
// in the slice file. For example: `useSelector((state: RootState) => state.counter.value)`
export const userSelector = (state: RootState) => state.entities.user;
export const tokenSelector = (state: RootState) => state.entities.user.token;

export default userSlice.reducer;


// Define actions creators.
export const actionCreators = {
  login: (model: LoginFormValues) => async (dispatch: Dispatch) => {
    try {
      const result = await agent.Account.login(model);
      if (result.success) {
        dispatch(userSlice.actions.login(result));
        history.push('/home');
      }
    } catch (error) {
      console.log(error,'login error catch t');
    }
  },

  register: (model: RegisterFormValues) => async (dispatch: Dispatch) => {
    try {
      const result = await agent.Account.register(model);
      if (result.status==='success') {
        toast('Registration successful', {
          position: "bottom-right",
          autoClose: 3000,
          closeOnClick: true,
          });
      }else{
        toast(result.message, {
          position: "bottom-right",
          autoClose: 3000,
          closeOnClick: true,
          });
      }
    } catch (error) {
      console.log(error,'register reducer catch')
      // toast(String(error), {
      //   position: "top-right",
      //   autoClose: 3000,
      //   hideProgressBar: false,
      //   closeOnClick: true,
      //   });
    }
  },

  logout: () => async (dispatch: Dispatch) => {
        dispatch(userSlice.actions.logout());
        history.push('/login');
  },
};