import { combineReducers } from 'redux';
import counterReducer from './slices/counterSlice';
import userReducer from './slices/userSlice';
import categooryReducer from './slices/categoryStore';
import productReducer from './slices/productStore';
import { persistReducer } from 'redux-persist';
import storage from 'redux-persist/lib/storage';

const persistConfig = {
  key: 'root',
  storage: storage,
  whitelist: ['counter'] // which reducer want to store
};

const rootReducer = combineReducers({
  counter: counterReducer,
  user: userReducer,
  category:categooryReducer,
  product:productReducer
});

export default persistReducer(persistConfig,rootReducer);
