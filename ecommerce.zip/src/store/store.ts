import { configureStore, ThunkAction, Action, getDefaultMiddleware } from '@reduxjs/toolkit';
import entities from './reducers';
import { persistStore } from 'redux-persist';

export const store = configureStore({
  reducer: {
    entities,
  },
  middleware: [
    ...getDefaultMiddleware({
      serializableCheck: false
    }),
  ],
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>;

export const persistor = persistStore(store);