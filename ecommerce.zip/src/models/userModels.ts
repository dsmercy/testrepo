export interface User {
    id: number;
    username: string;
    displayName: string;
    token: string;
    image?: string;
    success?: boolean;
    message?: string;
}


export interface LoginFormValues {
    username: string;
    password: string;
}

export interface RegisterFormValues {
    username: string;
    email: string;
    password: string;
}
