
export interface Product {
    id?:number;
    name: string;
    description: string;
    image:File;
    sellingprice:number;
    unitsinstock:number;
    productcategoryid:number;
}