export interface RegisterResponse {
    status: string;
    message: string;
}