import { Route, Switch, useLocation } from 'react-router-dom';
import Home from './views/shared/Home';
import Header from "./views/shared/Header";
import { Container } from 'semantic-ui-react';
import Login from './views/user/Login';
import Profile from './views/user/Profile';
import ForgotPassword from './views/user/ForgotPassword';
import UpdateProfile from './views/user/UpdateProfile';
import Register from './views/user/Register';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import NewProduct from './views/admin/NewProduct';

function App() {
  return (
    <>
      <Header />
      <Container style={{ marginTop: '3em' }}>
        <Switch>
          <Route exact path="/" component={Home} />
          <Route exact path="/home" component={Home} />
          <Route path='/login' component={Login} />
          <Route path='/profile' component={Profile} />
          <Route path='/forgotpassword' component={ForgotPassword} />
          <Route path='/updateprofile' component={UpdateProfile} />
          <Route path='/register' component={Register} />
          <Route path='/addproduct' component={NewProduct} />
        </Switch>
        <ToastContainer />
      </Container>

    </>
  );
}

export default App;
