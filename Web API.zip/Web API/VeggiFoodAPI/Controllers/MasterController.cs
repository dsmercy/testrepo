﻿using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace VeggiFoodAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MasterController : ControllerBase
    {
        [HttpGet("getskilllist")]
        public ActionResult GetSkilllist()
        {
            var customObject = new
            {
                data = new[] { new { Id = 1, SkillName = "Java" }, new { Id = 2, SkillName = "python" }, new { Id = 3, SkillName = "Xamrin" } },
                Message = "Data Fetch Successfully",
                StatusCode = 200,
                Success = true
            };

            return Ok(customObject);
        }
        [HttpGet("getdegreelist")]
        public ActionResult GetDegreeList()
        {
            var customObject = new
            {
                data = new[] { new { Id = 1, DegreeName = "MCA" }, new { Id = 2, DegreeName = "BCA" } },
                Message = "Data Fetch Successfully",
                StatusCode = 200,
                Success = true
            };

            return Ok(customObject);
        }

        [HttpGet("getfieldofstudylist")]
        public ActionResult GetFieldOfStudyList()
        {
            var customObject = new
            {
                data = new[] { new { Id = 1, FieldOfStudy = "AI" }, new { Id = 2, FieldOfStudy = "Machine Learning" } },
                Message = "Data Fetch Successfully",
                StatusCode = 200,
                Success = true
            };

            return Ok(customObject);
        }

        [HttpGet("GetUniversityList")]
        public ActionResult GetUniversityList()
        {
            var customObject = new
            {
                data = new[] { new { Id = 1, University = "Noida University" }, new { Id = 2, University = "Meerut University" } },
                Message = "Data Fetch Successfully",
                StatusCode = 200,
                Success = true
            };

            return Ok(customObject);
        }

        [HttpGet("getyearofcomplitionlist")]
        public ActionResult GetYearOfComplitionList()
        {
            var customObject = new
            {
                data = new[] { new { YearOfCompletion = "2018" }, new { YearOfCompletion = "2019" } },
                Message = "Data Fetch Successfully",
                StatusCode = 200,
                Success = true
            };

            return Ok(customObject);
        }
    }
}
