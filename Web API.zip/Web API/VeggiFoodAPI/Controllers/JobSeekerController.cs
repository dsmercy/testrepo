﻿using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace VeggiFoodAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class JobSeekerController : ControllerBase
    {
        [HttpPost("postjobseekerdetails")]
        public ActionResult PostJobSeekerDetails(List<JobSeekerPayload> jobSeekers)
        {
            return Ok("post success");
        }
        [HttpGet("getjobseekerdetails")]
        public ActionResult GetJobSeekerDetails()
        {

            var educationData = new List<JobSeeker>
        {
            new JobSeeker
            {
                DegreeId = 1,
                DegreeName = "MCA",
                FieldOfStudyId = 1,
                FieldOfStudyName = "AI",
                ClgNameId=1,
                CollegeName = "Noida University",
                yearofCompletion = 2018
            },
            new JobSeeker
            {
                DegreeId = 1,
                DegreeName = "BCA",
                FieldOfStudyId = 1,
                FieldOfStudyName = "Machine Learning",
                ClgNameId=1,
                CollegeName = "Meerut University",
                yearofCompletion = 2019
            }
        };

            var customObject = new
            {
                data = educationData,
                Message = "Data Fetch Successfully",
                StatusCode = 200,
                Success = true
            };

            return Ok(customObject);

        }
    }
    public class JobSeekerPayload
    {
        public int DegreeName { get; set; }
        public int FieldOfStudy { get; set; }
        public int CollegeName { get; set; }
        public int yearofCompletion { get; set; }
    }
    public class JobSeeker
    {
        public int DegreeId { get; set; }
        public string DegreeName { get; set; }
        public int FieldOfStudyId { get; set; }
        public string FieldOfStudyName { get; set; }
        public int ClgNameId { get; set; }
        public string CollegeName { get; set; }
        public int yearofCompletion { get; set; }
    }
}
