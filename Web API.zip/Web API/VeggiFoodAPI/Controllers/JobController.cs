﻿using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace VeggiFoodAPI.Controllers
{
    [Route("api")]
    [ApiController]
    public class JobController : ControllerBase
    {
        private readonly List<Job> jobs;

        public JobController()
        {
            // Initialize job data in the constructor
            jobs = new List<Job>
            {
                new Job { Id = 8, Title = "Python Developer", Description = "This job for IT department", Department = "IT", MinimumExperience = 2.5, MaximumExperience = 5.5, AnnualCTC = 0, NumberOfVacancy = 2 },
                new Job { Id = 12, Title = "DotNet", Description = "This is Demo For Testing", Department = "IT", MinimumExperience = 2.5, MaximumExperience = 5.3, AnnualCTC = 0, NumberOfVacancy = 4 },
                new Job { Id = 14, Title = "DotNet", Description = "This is Demo For Testing", Department = "IT", MinimumExperience = 2.5, MaximumExperience = 5.3, AnnualCTC = 0, NumberOfVacancy = 4 },
                new Job { Id = 15, Title = "DotNet", Description = "This is Demo For Testing", Department = "HR", MinimumExperience = 2.5, MaximumExperience = 5.3, AnnualCTC = 0, NumberOfVacancy = 4 },
                new Job { Id = 16, Title = "DotNet", Description = "This is Demo For Testing", Department = "HR", MinimumExperience = 2.5, MaximumExperience = 5.3, AnnualCTC = 0, NumberOfVacancy = 4 },
                new Job { Id = 17, Title = "DotNet", Description = "This is Demo For Testing", Department = "HR", MinimumExperience = 2.5, MaximumExperience = 5.3, AnnualCTC = 0, NumberOfVacancy = 4 },
                new Job { Id = 18, Title = "DotNet", Description = "This is Demo For Testing", Department = "HR", MinimumExperience = 2.5, MaximumExperience = 5.3, AnnualCTC = 0, NumberOfVacancy = 4 },
                new Job { Id = 19, Title = "DotNet", Description = "This is Demo For Testing", Department = "ACCOUNTS", MinimumExperience = 2.5, MaximumExperience = 5.3, AnnualCTC = 0, NumberOfVacancy = 4 },
                new Job { Id = 20, Title = "DotNet", Description = "This is Demo For Testing", Department = "ACCOUNTS", MinimumExperience = 2.5, MaximumExperience = 5.3, AnnualCTC = 0, NumberOfVacancy = 4 },
                new Job { Id = 21, Title = "DotNet", Description = "This is Demo For Testing", Department = "ACCOUNTS", MinimumExperience = 2.5, MaximumExperience = 5.3, AnnualCTC = 0, NumberOfVacancy = 4 },
                new Job { Id = 22, Title = "Python", Description = "This is update demo For Testing", Department = "HR", MinimumExperience = 1, MaximumExperience = 3, AnnualCTC = 0, NumberOfVacancy = 4 },
                new Job { Id = 23, Title = "Arabic", Description = "This is Demo For Arabic", Department = "IT", MinimumExperience = 2.5, MaximumExperience = 5.3, AnnualCTC = 0, NumberOfVacancy = 4 },
                new Job { Id = 24, Title = "DotNet", Description = "This is Demo Job", Department = "IT", MinimumExperience = 2.5, MaximumExperience = 5.6, AnnualCTC = 0, NumberOfVacancy = 4 }
            };
        }
        [HttpGet("JobSeeker/SearchJobBasedOnSkill")]
        public ActionResult SearchJobBasedOnSkill()
        {
            var customObject = new
            {
                data = jobs,
                Message = "Data Fetch Successfully",
                StatusCode = 200,
                Success = true
            };

            return Ok(customObject);
        }
        [HttpPost("Job/FindJobs")]
        public ActionResult SearchJobBasedOnSkill([FromBody] Filter jobpayload)
        {
            var filteredJobs = jobs;
            if (!string.IsNullOrEmpty(jobpayload.jobIndustry)) {
                filteredJobs = jobs.Where(job => string.Equals(job.Department, jobpayload.jobIndustry, StringComparison.OrdinalIgnoreCase)).ToList();
            }
            var customObject = new
            {
                data = filteredJobs,
                Message = "Data Fetch Successfully",
                StatusCode = 200,
                Success = true
            };

            return Ok(customObject);
        }
    }

    public class Filter
    {
        public string? jobIndustry { get; set; }
        public string? jobExperience { get; set; }
    }
    public class Job
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string? Department { get; set; }
        public double MinimumExperience { get; set; }
        public double MaximumExperience { get; set; }
        public int AnnualCTC { get; set; }
        public int NumberOfVacancy { get; set; }
    }
}
