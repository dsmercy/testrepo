﻿namespace VeggiFoodAPI.Models
{
    public class ResponseModel
    {
        public Object? Data { get; set; }
        public List<string>? Errors { get; set; }
    }
}
