﻿using Microsoft.AspNetCore.Identity;

namespace VeggiFoodAPI.Models.DTOs
{
    public class ApplicationRole : IdentityRole<int>
    {

    }
}
