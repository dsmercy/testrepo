﻿namespace VeggiFoodAPI.Models.DTOs
{
    public class UserAddress
    {
        public int Id { get; set; }
    }
}
