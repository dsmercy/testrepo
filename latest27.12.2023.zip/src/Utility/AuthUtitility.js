export const Base_url= "https://vuesharvest-hucm-qa.chetu.com/";
export const Login_url= 'https://vuesharvest-hucm-qa.chetu.com/Account/Login';
export const Register_url="https://vuesharvest-hucm-qa.chetu.com/Account/SignUp";