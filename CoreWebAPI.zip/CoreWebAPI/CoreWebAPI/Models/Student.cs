﻿using System.Text.Json.Serialization;

namespace CoreWebAPI.Models
{
    public class Student
    {
        
        public int Id { get; set; }
        public string? Username { get; set; }    
        public string? DOB { get; set; }    
        public string? Email { get; set; }    
        public string? Password { get; set; }    
        public string? Gender { get; set; }    
        public int Rollnumber { get; set; }    

    }
}
