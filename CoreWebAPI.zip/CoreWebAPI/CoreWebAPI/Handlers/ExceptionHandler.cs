﻿using CoreWebAPI.Models;

namespace CoreWebAPI.Handlers
{
    public class ExceptionHandler
    {
        private readonly RequestDelegate _next;
        private readonly IHostEnvironment _env;
        private readonly LogHandler _LogHandler;
        public ExceptionHandler(RequestDelegate next,
            IHostEnvironment env)
        {
            _env = env;
            _next = next;
            _LogHandler = new LogHandler();
        }

        public async Task InvokeAsync(HttpContext context)
        {
            var routeData = context.Request.RouteValues;
            try
            {
                await _next(context);
            }
            catch (Exception ex)
            {
                var response = _env.IsDevelopment()
                      ? new ExceptionModel(ex.Message, ex.Data.ToString(), ex.InnerException?.ToString(), ex.StackTrace, routeData["controller"].ToString(), routeData["action"].ToString())
                      : new ExceptionModel(ex.Message, ex.Data.ToString(), ex.InnerException?.ToString(), ex.StackTrace, routeData["controller"].ToString(), routeData["action"].ToString());

                _LogHandler.WriteError(response);
                //context.Response.Redirect("/Home/error");
                context.Response.StatusCode=500;
            }
        }
    }
}
