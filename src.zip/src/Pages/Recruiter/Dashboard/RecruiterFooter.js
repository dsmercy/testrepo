import React from 'react'

const RecuriterFooter = () => {
  return (
    <>
      <div className='rec-footer'>
        <p>2024 copyright: Poppin’ Job.com</p>
      </div>
    </>
  )
}

export default RecuriterFooter
