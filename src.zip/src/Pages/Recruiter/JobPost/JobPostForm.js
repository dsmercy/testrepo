import React,{ useState } from "react";
import {
  Button,
  Col,
  Container,
  Form,
  FormLabel,
  InputGroup,
  Modal,
  Row,
} from "react-bootstrap";
import FormWizard from "react-form-wizard-component";
import speaker from "../../../assets/images/38767-ai.png";
import Select from "react-dropdown-select";
import jobImage1 from "../../../assets/images/Group 2118.png";
import jobImage2 from "../../../assets/images/Group 2119.png";
import jobImage3 from "../../../assets/images/Group 2120.png";
import jobImage4 from "../../../assets/images/Rectangle 1782.png";
import Jobmodal from "../../../assets/images/Layer 1.png";
import RecuriterFooter from "../Dashboard/RecruiterFooter";
import RecruiterHeader from "../Dashboard/RecruiterHeader";
import RecruiterMain from "../Dashboard/RecruiterMain";

const JobPostForm = () => {
  const [SidebarOpen, setSidebarOpen] = useState(true);

  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const handleComplete = () => {
    console.log("Form completed!");
  };
  const tabChanged = ({ prevIndex, nextIndex }) => {
    console.log("prevIndex", prevIndex);
    console.log("nextIndex", nextIndex);
  };

  const options = [
    { id: "Full Time", name: 1 },
    { id: "Part Time", name: 2 },
    { id: "Remote", name: 3 },
    { id: "Fresher", name: 4 },
    { id: "Internship", name: 5 },
    { id: "Freelance", name: 6 },
    { id: "Regular/permanent", name: 7 },
  ];
  const optionsOne = [
    { id: "Day Shift", name: 1 },
    { id: "Night Shift", name: 2 },
    { id: "Part Time", name: 3 },
    { id: "4 Hour Shift", name: 4 },
    { id: "12 Hours", name: 5 },
    { id: "Other", name: 6 },
  ];
  const optionsTwo = [
    { id: "Signing Bonus", name: 1 },
    { id: "Commission pay", name: 2 },
    { id: "Performance", name: 3 },
    { id: "Tips", name: 4 },
    { id: "More", name: 5 },
  ];
  const optionsThree = [
    { id: "Life Insurance", name: 1 },
    { id: "Paid Time off", name: 2 },
    { id: "Retirement plan", name: 3 },
    { id: "Health insurance", name: 4 },
    { id: "Other", name: 6 },
  ];

  return (
    <>
      <div
        className={`dashboard ${SidebarOpen ? "dashboard-app-sidebar" : ""}`}
      >
        <RecruiterMain />

        <div className={`dashboard-app`}>
          <RecruiterHeader
            setSidebarOpen={setSidebarOpen}
            SidebarOpen={SidebarOpen}
          />

          <Container>
            <Row>
              <Col lg={4} sm={12}>
                <div className="job-post-benefits">
                  <div className="job-post-benefits-inner">
                    <h4>Employer Benefits</h4>
                    <img src={speaker} alt="image" />
                  </div>
                  <div className="job-post-benefits-content">
                    <div>
                      <i className="fa fa-check-circle"></i>
                      <p>
                        Branded Career Centers with built in social media
                        integration.
                      </p>
                    </div>
                    <div>
                      <i className="fa fa-check-circle"></i>
                      <p>Engage prospective employees</p>
                    </div>
                    <div>
                      <i className="fa fa-check-circle"></i>
                      <p>
                        Poppin’ Job attracts their customers for the lifetime of
                        their career
                      </p>
                    </div>
                  </div>
                </div>
              </Col>
              <Col lg={8} sm={12}>
                <div className="job-post">
                  <div className="job-post-head">
                    <h4>
                      Job <span>Post</span>
                    </h4>
                    <p>
                      Fill out the details below to post your job and get paired
                      with top talent.
                    </p>
                  </div>
                  <FormWizard
                    shape="circle"
                    color="#1DA425"
                    onComplete={handleComplete}
                    onTabChange={tabChanged}
                    nextButtonTemplate={(handleNext) => (
                      <div
                        class="wizard-footer-right"
                        style={{
                          backgroundColor: "rgb(29, 164, 37)",
                          borderColor: "rgb(29, 164, 37)",
                          borderRadius: "4px",
                        }}
                      >
                        <button
                          class="wizard-btn"
                          type="button"
                          onClick={handleNext}
                        >
                          Continue
                        </button>
                      </div>
                    )}
                  >
                    <FormWizard.TabContent title="" icon="fa fa-check">
                      <div className="job-post-basic-detail">
                        <h4>Basic Details</h4>

                        <FormLabel>
                          Country where job post is shown{" "}
                          <span className="text-danger">*</span>
                        </FormLabel>
                        <Form.Select
                          aria-label="Default select example"
                          className="mb-3"
                        >
                          <option>Open this select menu </option>
                          <option value="1">BCA</option>
                          <option value="2">MCA</option>
                          <option value="3">BTech</option>
                        </Form.Select>
                        <FormLabel>
                          Language of job post{" "}
                          <span className="text-danger">*</span>
                        </FormLabel>
                        <Form.Select
                          aria-label="Default select example"
                          className="mb-3"
                        >
                          <option>Open this select menu </option>
                          <option value="1">BCA</option>
                          <option value="2">MCA</option>
                          <option value="3">BTech</option>
                        </Form.Select>

                        <FormLabel>
                          Job title<span className="text-danger">*</span>
                        </FormLabel>
                        <InputGroup className="mb-3">
                          <Form.Control
                            type="email"
                            placeholder="UI/UX Designer"
                            aria-label="Username"
                            aria-describedby="basic-addon1"
                          />
                        </InputGroup>

                        <FormLabel>
                          Academic Qualification
                          <span className="text-danger">*</span>
                        </FormLabel>
                        <InputGroup className="mb-3">
                          <Form.Control
                            type="email"
                            placeholder="Graduate"
                            aria-label="Username"
                            aria-describedby="basic-addon1"
                          />
                        </InputGroup>

                        <Row>
                          <Col>
                            <FormLabel>
                              {" "}
                              Required Experience{" "}
                              <span className="text-danger">*</span>
                            </FormLabel>
                            <Form.Select
                              aria-label="Default select example"
                              className="mb-3"
                            >
                              <option>Minium </option>
                              <option value="1">BCA</option>
                              <option value="2">MCA</option>
                              <option value="3">BTech</option>
                            </Form.Select>
                          </Col>
                          <Col>
                            <FormLabel>
                              {" "}
                              Required Experience
                              <span className="text-danger">*</span>
                            </FormLabel>
                            <Form.Select
                              aria-label="Default select example"
                              className="mb-3"
                            >
                              <option>Maxium </option>
                              <option value="1">BCA</option>
                              <option value="2">MCA</option>
                              <option value="3">BTech</option>
                            </Form.Select>
                          </Col>
                        </Row>

                        <div className="job-post-report-add">
                          <p>Where will an employee report to work? *</p>

                          <InputGroup className="mb-3">
                            <InputGroup.Radio aria-label="Radio button for following text input" />
                            <Form.Control
                              aria-label="Text input with radio button"
                              placeholder="Employees will report to a specific address"
                            />
                          </InputGroup>

                          <InputGroup className="mb-3">
                            <InputGroup.Radio aria-label="Radio button for following text input" />
                            <Form.Control
                              aria-label="Text input with radio button"
                              placeholder="Employees will not report to a specific address"
                            />
                          </InputGroup>

                          <InputGroup className="mb-3">
                            <InputGroup.Radio aria-label="Radio button for following text input" />
                            <Form.Control
                              aria-label="Text input with radio button"
                              placeholder="Employees will work remotely"
                            />
                          </InputGroup>

                          <FormLabel>
                            Street Address<span className="text-danger">*</span>
                          </FormLabel>
                          <InputGroup className="mb-3">
                            <Form.Control
                              type="email"
                              placeholder=""
                              aria-label="Username"
                              aria-describedby="basic-addon1"
                            />
                          </InputGroup>

                          <Row>
                            <Col lg={4} sm={12}>
                              <FormLabel>
                                City <span className="text-danger">*</span>
                              </FormLabel>
                              <InputGroup className="mb-3">
                                <Form.Control
                                  type="Eutawville"
                                  placeholder=""
                                  aria-label="Username"
                                  aria-describedby="basic-addon1"
                                />
                              </InputGroup>
                            </Col>
                            <Col lg={4} sm={12}>
                              <FormLabel>
                                ZIP <span className="text-danger">*</span>
                              </FormLabel>
                              <InputGroup className="mb-3">
                                <Form.Control
                                  type="29048"
                                  placeholder=""
                                  aria-label="Username"
                                  aria-describedby="basic-addon1"
                                />
                              </InputGroup>
                            </Col>
                            <Col lg={4} sm={12}>
                              <FormLabel>
                                {" "}
                                State <span className="text-danger">*</span>
                              </FormLabel>
                              <Form.Select
                                aria-label="Default select example"
                                className="mb-3"
                              >
                                <option>Select State </option>
                                <option value="1">BCA</option>
                                <option value="2">MCA</option>
                                <option value="3">BTech</option>
                              </Form.Select>
                            </Col>
                          </Row>

                          <div className="job-post-location-map">
                            <iframe
                              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3805.7644676220384!2d78.18366597594104!3d17.47098380038997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcbefc79ade9549%3A0x58f900af5f527dbc!2sv%20locaction!5e0!3m2!1sen!2sin!4v1705658095415!5m2!1sen!2sin"
                              allowFullScreen
                              loading="lazy"
                              referrerPolicy="no-referrer-when-downgrade"
                            />
                          </div>
                        </div>
                      </div>
                    </FormWizard.TabContent>

                    <FormWizard.TabContent title="" icon="fa fa-check">
                      <div className="job-post-job-detail">
                        <h4>Job Details</h4>

                        <FormLabel>
                          {" "}
                          What is the job type?{" "}
                          <span className="text-danger">*</span>
                        </FormLabel>
                        <Select
                          name="select"
                          options={options}
                          labelField="id"
                          valueField="name"
                          multi
                        ></Select>

                        <FormLabel>
                          {" "}
                          What is the schedule for this job?{" "}
                          <span className="text-danger">*</span>
                        </FormLabel>
                        <Select
                          name="select"
                          options={optionsOne}
                          labelField="id"
                          valueField="name"
                          multi
                        ></Select>

                        <FormLabel>
                          {" "}
                          How many people do you want to hire for this opening?{" "}
                          <span className="text-danger">*</span>
                        </FormLabel>
                        <Form.Select
                          aria-label="Default select example"
                          className="mb-3"
                        >
                          <option>2 </option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </Form.Select>

                        <FormLabel>
                          {" "}
                          Planned Start Date{" "}
                          <span className="text-danger">*</span>
                        </FormLabel>
                        <Form.Select
                          aria-label="Default select example"
                          className="mb-3"
                        >
                          <option>1-3 Weeks </option>
                          <option value="1">1 Week</option>
                          <option value="2">2 Week</option>
                          <option value="3">3 Week</option>
                        </Form.Select>
                      </div>
                    </FormWizard.TabContent>
                    <FormWizard.TabContent title="" icon="fa fa-check">
                      <div className="job-post-add-compensation">
                        <h4>Add Compensation</h4>
                        <p>What is the pay rate or range?</p>

                        <FormLabel> Show Pay By </FormLabel>
                        <Form.Select
                          aria-label="Default select example"
                          className="mb-3"
                        >
                          <option>Range </option>
                          <option value="1">1</option>
                          <option value="2">2</option>
                          <option value="3">3</option>
                        </Form.Select>

                        <Row>
                          <Col>
                            <FormLabel> Currency </FormLabel>
                            <Form.Select
                              aria-label="Default select example"
                              className="mb-3"
                            >
                              <option>USD </option>
                              <option value="1">1 Week</option>
                              <option value="2">2 Week</option>
                              <option value="3">3 Week</option>
                            </Form.Select>
                          </Col>
                          <Col lg={4} sm={12}>
                            <FormLabel> Minimum </FormLabel>
                            <InputGroup className="mb-3">
                              <Form.Control
                                type="29048"
                                placeholder="90.688.20 "
                                aria-label="Username"
                                aria-describedby="basic-addon1"
                              />
                            </InputGroup>
                          </Col>
                          <Col lg={4} sm={12}>
                            <FormLabel> Maximum </FormLabel>
                            <InputGroup className="mb-3">
                              <Form.Control
                                type="29048"
                                placeholder="105,200.40 "
                                aria-label="Username"
                                aria-describedby="basic-addon1"
                              />
                            </InputGroup>
                          </Col>
                          <Col lg={4} sm={12}>
                            <FormLabel> Rate </FormLabel>
                            <Form.Select
                              aria-label="Default select example"
                              className="mb-3"
                            >
                              <option>Per Year </option>
                              <option value="1">1 Week</option>
                              <option value="2">2 Week</option>
                              <option value="3">3 Week</option>
                            </Form.Select>
                          </Col>
                        </Row>

                        <FormLabel>
                          Do you offer any of the following supplemental pay?{" "}
                        </FormLabel>
                        <Select
                          name="select"
                          options={optionsTwo}
                          labelField="id"
                          valueField="name"
                          multi
                        ></Select>

                        <FormLabel>
                          {" "}
                          Are any of the following benefits offered?{" "}
                        </FormLabel>
                        <Select
                          name="select"
                          options={optionsThree}
                          labelField="id"
                          valueField="name"
                          multi
                        ></Select>
                      </div>
                    </FormWizard.TabContent>
                    <FormWizard.TabContent title="" icon="fa fa-check">
                      <div className="job-post-describe">
                        <h4>Describe the job</h4>
                        <h5>
                          Job Description <span className="text-danger">*</span>
                        </h5>
                        <p>
                          Describe the responsibilities of the role, required
                          work experience, skills and education.
                        </p>

                        <div className="cont-editor">
                          <div id="editor" contenteditable="false">
                            <section id="toolbar">
                              <div id="bold" className="icon fa fa-bold"></div>
                              <div
                                id="italic"
                                className="icon fa fa-italic"
                              ></div>
                              <div
                                id="createLink"
                                className="icon fa fa-link"
                              ></div>
                              <div
                                id="insertUnorderedList"
                                className="icon fa fa-list"
                              ></div>
                              <div
                                id="insertOrderedList"
                                className="icon fa fa-list-ol"
                              ></div>
                              <div
                                id="justifyLeft"
                                className="icon fa fa-align-left"
                              ></div>
                              <div
                                id="justifyRight"
                                className="icon fa fa-align-right"
                              ></div>
                              <div
                                id="justifyCenter"
                                className="icon fa fa-align-center"
                              ></div>
                              <div
                                id="justifyFull"
                                className="icon fa fa-align-justify"
                              ></div>
                            </section>

                            <div id="page" contenteditable="true">
                              <p id="page-content"></p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </FormWizard.TabContent>
                    <FormWizard.TabContent title="" icon="fa fa-check">
                      <div className="job-post-basic-detail-edit">
                        <h4>
                          Basic Details <i className="fa fa-edit"></i>{" "}
                        </h4>
                        <div className="job-post-basic-detail-edit-inner">
                          <p>Country where job post is shown :</p>
                          <h4>United kingdom</h4>
                          <p>Language of Job Post :</p>
                          <h4>English</h4>
                          <p>Job Title :</p>
                          <h4>UI/UX designer</h4>
                          <p>Required Experience :</p>
                          <h4>0 to 5 Year</h4>
                          <p>Required skills :</p>
                          <h4>
                            HTML, CSS, JavaScript, Bootstrap, Photoshop, JQuery
                          </h4>
                          <p>Company Photos and Videos :</p>
                          <div className="job-post-image">
                            <img src={jobImage1} alt="image" />
                            <img src={jobImage2} alt="image" />
                            <img src={jobImage3} alt="image" />
                            <img src={jobImage4} alt="image" />
                          </div>
                          <p>Where will an employee report to work? :</p>
                          <h4>Employees will report to a specific address</h4>
                          <p>Street Address :</p>
                          <h4>226 Porcher Ave, United States</h4>
                          <Row>
                            <Col>
                              <p>City :</p>
                              <h4>Eutawville</h4>
                            </Col>
                            <Col>
                              <p>Pin Code :</p>
                              <h4>29048</h4>
                            </Col>
                            <Col>
                              <p>State :</p>
                              <h4>California</h4>
                            </Col>
                          </Row>
                        </div>
                        <h4>
                          Job Details <i className="fa fa-edit"></i>{" "}
                        </h4>
                        <div className="job-post-basic-detail-edit-inner">
                          <p>What is the job type? :</p>
                          <h4>Regular/Permanent</h4>
                          <p>What is the schedule for this job :</p>
                          <h4>Day shift</h4>
                          <p>
                            How many people do you want to hire for this
                            opening? :
                          </p>
                          <h4>2</h4>
                          <p>How quickly do you need to hire? :</p>
                          <h4>1 to 3 days</h4>
                        </div>
                        <h4>
                          Add compensation <i className="fa fa-edit"></i>{" "}
                        </h4>
                        <div className="job-post-basic-detail-edit-inner">
                          <h4>What is the pay rate or range?</h4>
                          <p>Show Pay By</p>
                          <h4>Range</h4>
                          <p>Minimum to Maximum</p>
                          <h4>$ 90,688.20 to $ 105,200.40</h4>
                          <p>
                            Do you offer any of the following supplemental pay?
                            :
                          </p>
                          <h4>Performance bonus</h4>
                          <p>Are any of the following benefits offered? :</p>
                          <h4>Health insurance</h4>
                        </div>
                        <h4>
                          Describe the job <i className="fa fa-edit"></i>{" "}
                        </h4>
                        <div className="job-post-basic-detail-edit-inner">
                          <p>Job Description</p>
                          <p>
                            Strong experience with React and React-Native
                            Experience with Angular and WordPress. Knowledge of
                            CI/CD is a plus. Strong understanding of HTML, CSS
                            and JavaScript.
                          </p>
                        </div>
                      </div>
                      <Button variant="link" onClick={handleShow}>
                        Modal Pop Up
                      </Button>
                    </FormWizard.TabContent>
                  </FormWizard>
                </div>
              </Col>
            </Row>
          </Container>

          <RecuriterFooter />
          <div className="job-post-modal">
            <Modal
              show={show}
              onHide={handleClose}
              animation={false}
              centered
              backdrop="static"
              keyboard={false}
            >
              <Modal.Header closeButton>
                <Modal.Title></Modal.Title>
              </Modal.Header>
              <Modal.Body>
                <img src={Jobmodal} alt="image" />
                <h4>Your job has been posted successfully</h4>
                <p>
                  You will get an email confirmation at{" "}
                  <strong> adamsmith@gmail.com</strong>
                </p>
                <Button
                  variant=""
                  id="job-post-modal-btn"
                  onClick={handleClose}
                >
                  Done
                </Button>
              </Modal.Body>
            </Modal>
          </div>
        </div>
      </div>
    </>
  );
};

export default JobPostForm;
