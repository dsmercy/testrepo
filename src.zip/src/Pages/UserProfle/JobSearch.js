import React, { useEffect, useState } from "react";
import { Button, Col, Row } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import Services from "../../services/Services";

export const JobSearch = () => {
  const [jobType,setJobType]=useState([]);
  const [industryType,setIndustryType]=useState([]);
  const navigate = useNavigate();

  useEffect(()=>{
    getJobType();
    getIndustryType();
  },[]);

  const getJobType=()=>{
    Services.Job.jobTypeList().then((res)=>setJobType(res?.data)).catch((errors)=>console.log(errors));
    
  }
  const getIndustryType=()=>{
    Services.Job.industryList().then((res)=>setIndustryType(res?.data)).catch((errors)=>console.log(errors));
    
  }
  const [formState, setFormState] = useState({
    skill: "",
    experience: "",
    location: "",
  });

  const handleInputChange = (event) => {
    setFormState({
      ...formState,
      [event.target.name]: event.target.value,
    });
  };

  const handleSearchClick = () => {
    const body={
      jobSkill:"",
      jobTitle:"",
      jobExperience:"",
      jobLocation:"",
      jobIndustry:"",
      jobType:"",
      dateOfPosted:""
    }
    Services.Job.searchJob(body).then((res)=>console.log(res)).catch((errors)=>console.log(errors))
    navigate("/search-jobs");
  };

  return (
    <>
      <div className="employee-dashboard">
        <h5>Find your dream job now</h5>
        <div className="search-container">
          <Row className="w-100">
            <Col lg={4} sm={12}>
              <input
                type="text"
                className="form-control"
                placeholder="Enter skill / designation /company name"
                name="skill"
                onChange={handleInputChange}
              />
            </Col>
            <Col lg={3} sm={12}>
              <select
                className="form-select"
                name="experience"
                onChange={handleInputChange}
              >
                <option>Select Experience</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
              </select>
            </Col>

            <Col lg={3} sm={12}>
              <input
                type="text"
                className="form-control"
                placeholder="Enter Location"
                name="location"
                onChange={handleInputChange}
              />
            </Col>
            <Col lg={2} sm={12}>
              <div className="search-container-btn">
                <Button variant="" onClick={handleSearchClick}>
                  Search
                </Button>
              </div>
            </Col>
          </Row>
        </div>

        <div className="search-filter">
          <Row>
            <Col>
              <select className="form-select">
                <option>Date of Posted</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
              </select>
            </Col>

            <Col>
              <select className="form-select">
                <option>Industry</option>{industryType.map((item,index)=>(<option key={index}>{item}</option>))}
              </select>
            </Col>

            <Col>
              <select className="form-select">
                <option>Job Type</option>
                {
                  jobType.map((item,index)=>( <option key={index}>{item.jobTypeName}</option>))
                }
                </select>
            </Col>

            <Col>
              <select className="form-select">
                <option>Education</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
              </select>
            </Col>

            <Col>
              <select className="form-select">
                <option>Salary</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
              </select>
            </Col>
          </Row>
        </div>
      </div>
    </>
  );
};
