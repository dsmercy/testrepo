import React, { useEffect, useState } from "react";
import { Button, Col, Row } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import Services from "../../services/Services";
import useJobsStore from "../../store/useJobsStore";

export const JobSearch = ({ userdashboard, jobFilters }) => {
  const [jobType, setJobType] = useState([]);
  const [industryType, setIndustryType] = useState([]);
  const [errorExp, setErrorExp] = useState("");
  const [errorSkill, setErrorSkill] = useState("");
  const navigate = useNavigate();
  const filterJobs = useJobsStore((state) => state.filterJobs);
  const { setSearchInput, searchInput, setExperience, selectExperience } =
    useJobsStore();
  useEffect(() => {
    getJobType();
    getIndustryType();
  }, []);

  console.log("jobFilters", jobFilters);

  const getJobType = () => {
    Services.Job.jobTypeList()
      .then((res) => setJobType(res?.data))
      .catch((errors) => console.log(errors));
  };
  const getIndustryType = () => {
    Services.Job.industryList()
      .then((res) => setIndustryType(res?.data))
      .catch((errors) => console.log(errors));
  };
  const [formState, setFormState] = useState({
    skill: "",
    experience: "",
    location: "",
    jobType: "",
    jobIndustry: "",
    jobEducation: "",
    dateOfPosted: "",
    jobTitle: "",
  });

  console.log("jobFilters", jobFilters);
  const handleInputChange = (event) => {
    console.log("jdjskdjhkldkl");
    event.preventDefault();
    const { name, value } = event.target;
    if (name === "skill") {
      // if (location.path) {
      setSearchInput(value);
      // }
    }
    if (name === "experience") {
      setExperience(value);
    } else {
      setFormState({
        ...formState,
        [name]: value,
      });
    }
    setErrorExp("");
    setErrorSkill("");
  };
  const handleSearchClick = () => {
    console.log("formState", formState);
    // if (!formState.experience && userdashboard) {
    //   setErrorExp("Please select your experience11.");
    //   return;
    // }
    filterJobs(formState.skill);
    if (!searchInput) {
      setErrorSkill("Please enter your SKILL.");
      return;
    }
    if (selectExperience === null) {
      setErrorExp("Please select your experience11");
      return;
    }
    // if (!jobFilters?.jobExperience ) {
    //   setErrorExp("Please select your experience33.");
    //   return;
    // }
    // if(!formState.skill || jobFilters?.jobSkill){
    //   setErrorSkill("Please enter your SKILL.");
    //   return;
    // }
    setErrorExp("");
    setErrorSkill("");
    const body = {
      jobSkill: searchInput,
      jobLocation: formState.location,
      jobExperience: selectExperience,
      jobTitle: searchInput || "",
      jobIndustry: formState.jobIndustry,
      jobType: formState.jobType,
      jobEducation: formState.jobEducation,
      dateOfPosted: "2024-01-20",
    };
    filterJobs(body);
    Services.Job.searchJob(body)
      .then((res) => console.log(res?.data))
      .catch((errors) => console.log(errors));
    if (userdashboard) {
      navigate("/search-jobs");
    }
    // setSearchInput("");
    // setExperience("");
  };
  console.log("selectExperience", selectExperience);
  console.log("searchInput", searchInput);
  return (
    <>
      <div className="search-container">
        <Row className="w-100">
          <Col lg={4} sm={12}>
            <input
              type="text"
              className="form-control"
              placeholder="Enter skill / designation /company name"
              name="skill"
              // defaultValue={
              //   formState.skill ? formState.skill : jobFilters?.jobSkill
              // }
              // value={formState.skill}
              value={searchInput || ""}
              onChange={handleInputChange}
            />
            {errorSkill && <p style={{ color: "#dc3545" }}>{errorSkill}</p>}
          </Col>
          <Col lg={3} sm={12}>
            <select
              className="form-select"
              name="experience"
              value={selectExperience || "selectExperience"}
              onChange={handleInputChange}
              required
            >
              <option disabled value="selectExperience">
                Select Experience
              </option>
              <option value={0}>0</option>
              <option value={2}>2</option>
              <option value={3}>3</option>
              <option value={4}>4</option>
            </select>
            {errorExp && <p style={{ color: "#dc3545" }}>{errorExp}</p>}
          </Col>

          <Col lg={3} sm={12}>
            <input
              type="text"
              className="form-control"
              placeholder="Enter Location"
              name="location"
              defaultValue={jobFilters?.jobLocation}
              onChange={handleInputChange}
            />
          </Col>
          <Col lg={2} sm={12}>
            <div className="search-container-btn">
              <Button variant="" onClick={handleSearchClick}>
                Search
              </Button>
            </div>
          </Col>
        </Row>
      </div>

      <div className="search-filter">
        <Row>
          <Col>
            <select
              className="form-select"
              name="dateOfPosted"
              onChange={handleInputChange}
            >
              <option>Date of Posted</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
            </select>
          </Col>

          <Col>
            <select
              className="form-select"
              name="jobIndustry"
              onChange={handleInputChange}
            >
              <option>Industry</option>
              {industryType.map((item, index) => (
                <option key={index}>{item}</option>
              ))}
            </select>
          </Col>

          <Col>
            <select
              className="form-select"
              name="jobType"
              onChange={handleInputChange}
            >
              <option>Job Type</option>
              {jobType.map((item, index) => (
                <option key={index}>{item.jobTypeName}</option>
              ))}
            </select>
          </Col>

          <Col>
            <select
              className="form-select"
              name="jobEducation"
              onChange={handleInputChange}
            >
              <option>Education</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
            </select>
          </Col>

          <Col>
            <select
              className="form-select"
              name="salary"
              onChange={handleInputChange}
            >
              <option>Salary</option>
              <option>2</option>
              <option>3</option>
              <option>4</option>
            </select>
          </Col>
        </Row>
      </div>
    </>
  );
};
